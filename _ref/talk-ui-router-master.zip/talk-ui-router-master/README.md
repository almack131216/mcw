talk-ui-router
==============

![Logo](/slides/themes/warsawjs/pictures/logo.png)
![Logo](/page/angularui.png)

Large Application Routing using AngularJS UI-Router

---
Licensed under [MIT License](http://en.wikipedia.org/wiki/MIT_License), see [license page](https://github.com/shower/shower/wiki/MIT-License) for details.
